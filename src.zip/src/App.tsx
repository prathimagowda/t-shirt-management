import React from "react";
import Header from "./Components/ReUsable/Header";
import "./App.css";
import OrderList from "./Components/Screens/OrderList";
import { Provider } from 'react-redux';
import {store} from '../src/Components/RTK/Store/store';

const App: React.FC = () =>
{
  return <div className="App">
    <Provider store={store}>
        <Header/>
        <OrderList/>
    </Provider>
  </div>
}

export default App;