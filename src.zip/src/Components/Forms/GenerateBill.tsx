import React from 'react'
import { BillValues, OrderFormValues } from '../RTK/Types/types'
import { Dialog, DialogContent, DialogTitle } from '@mui/material'
import { ErrorMessage, Field, Form, Formik } from 'formik';
import { useAddBillMutation } from '../RTK/Query/orderApi';

interface GenerateBillProp {
   open : boolean,
   handleClose :  () => void;
   existingOrderData : BillValues
}


 

 const GenerateBill : React.FC<GenerateBillProp> = ({existingOrderData,open,handleClose }) => {

   const [addBill] = useAddBillMutation()

   const initialValues: BillValues = existingOrderData || {
      orderNumber: '',
      customerName: '',
      phone: '',
      deliveryDate: '',
      price: 0,
      id:0,
      amountPaid : '',
      balanceAmount : '',
    };


   const handleSubmit = async (values: BillValues) => {
      console.log('BillValues:', values);
      try {
         const result = addBill(values);
         console.log("addBill", "billadded" , result);
      } catch (error) {
         console.log("addBill", error);
      }
   }
  
   return (
   <Dialog  open={open}  onClose={handleClose}   fullWidth maxWidth="md">
   <DialogTitle>Bill Form</DialogTitle>
 
      <DialogContent>
      <Formik
           initialValues={initialValues}
         //  validationSchema={validationSchema}
           onSubmit={handleSubmit}
          enableReinitialize 
        >
            <Form className='order_form'>
            <div>
              <label htmlFor="orderNumber">Order Number</label>
              <Field name="orderNumber" type="text" />
              <ErrorMessage name="orderNumber" component="div" />
            </div>
            
            <div>
              <label htmlFor="customerName">Customer Name</label>
              <Field name="customerName" type="text" />
              <ErrorMessage name="customerName" component="div" />
            </div>
            <div>
              <label htmlFor="phone">Phone</label>
              <Field name="phone" type="text" />
              <ErrorMessage name="phone" component="div" />
            </div>
            <div>
              <label htmlFor="deliveryDate">Delivery Date</label>
              <Field name="deliveryDate" type="date" />
              <ErrorMessage name="deliveryDate" component="div" />
            </div>
            <div>
              <label htmlFor="price">Price</label>
              <Field name="price" type="number" />
              <ErrorMessage name="price" component="div" />
            </div>
            <div>
              <label htmlFor="amountPaid">Amount paid</label>
              <Field name="amountPaid" type="number" />
              <ErrorMessage name="amountPaid" component="div" />
            </div>
            <div>
              <label htmlFor="balanceAmount">Balance Amount</label>
              <Field name="balanceAmount" type="number" />
              <ErrorMessage name="balanceAmount" component="div" />
            </div>
            <button className="button" type="submit">Submit</button>
            </Form>
            </Formik>
      </DialogContent>
      </Dialog>
  )
}

export default GenerateBill