import React from 'react'
import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from "@mui/material";
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useCreateOrderMutation, useUpdateOrderMutation } from '../RTK/Query/orderApi';
import {OrderFormValues, OrderValues } from '../RTK/Types/types';

interface orderFormProp{
  open : boolean,
  handleClose :  () => void;
  refetchList : ()=> void;
  editData?: any;
  existingOrder?: OrderFormValues; 
}



const Order: React.FC<orderFormProp> = ({open, handleClose, refetchList, existingOrder}) => {

  const [createOrder, { isLoading, isSuccess, isError, error }] = useCreateOrderMutation();
  const [updateOrder] = useUpdateOrderMutation();

  const initialValues: OrderFormValues = existingOrder || {
    orderNumber: '',
    customerName: '',
    email: '',
    phone: '',
    tShirtColor: '',
    printInfoFront: '',
    printInfoBack: '',
    quantity: 1,
    size: '',
    address: '',
    deliveryDate: '',
    price: 0,
    id:0
  };

  const validationSchema = Yup.object({
    orderNumber: Yup.string().required('Order Number is required'),
    customerName: Yup.string().required('Customer Name is required'),
    email: Yup.string().email('Invalid email format').required('Email is required'),
    phone: Yup.string().required('Phone is required'),
    tShirtColor: Yup.string().required('T-Shirt Color is required'),
    printInfoFront: Yup.string().required('Front Print Info is required'),
    printInfoBack: Yup.string().required('Back Print Info is required'),
    quantity: Yup.number().min(1, 'At least 1 item is required').required('Quantity is required'),
    size: Yup.string().required('Size is required'),
    address: Yup.string().required('Address is required'),
    deliveryDate: Yup.date().required('Delivery Date is required'),
    price: Yup.number().min(0, 'Price cannot be negative').required('Price is required'),
  });

  const handleSubmit = async (values: OrderValues) => {
    console.log('Order submitted:', values);
    try {
      if(existingOrder)
      {
        const result = await updateOrder({id: existingOrder.id, uOrder: values }).unwrap();
        console.log('Order upadted successfully:', result);
      }
      else{
        const result = await createOrder(values).unwrap();
        console.log('Order submitted successfully:', result);
      }
    
      refetchList()
      handleClose()
    } catch (err) {
      console.error('Failed to submit order:', err);
    }
  };
  
  return (
    <Dialog  open={open}  onClose={handleClose}   fullWidth maxWidth="md">
        <DialogTitle>Order Form</DialogTitle>
        <DialogContent>
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
          enableReinitialize 
        >
          <Form className='order_form'>
            <div>
              <label htmlFor="orderNumber">Order Number</label>
              <Field name="orderNumber" type="text" />
              <ErrorMessage name="orderNumber" component="div" />
            </div>
            
            <div>
              <label htmlFor="customerName">Customer Name</label>
              <Field name="customerName" type="text" />
              <ErrorMessage name="customerName" component="div" />
            </div>

            <div>
              <label htmlFor="email">Email</label>
              <Field name="email" type="email" />
              <ErrorMessage name="email" component="div" />
            </div>

            <div>
              <label htmlFor="phone">Phone</label>
              <Field name="phone" type="text" />
              <ErrorMessage name="phone" component="div" />
            </div>

            <div>
              <label htmlFor="tShirtColor">T-Shirt Color</label>
              <Field name="tShirtColor" type="text" />
              <ErrorMessage name="tShirtColor" component="div" />
            </div>

            <div>
              <label htmlFor="printInfoFront">Front Print Info</label>
              <Field name="printInfoFront" type="text" />
              <ErrorMessage name="printInfoFront" component="div" />
            </div>

            <div>
              <label htmlFor="printInfoBack">Back Print Info</label>
              <Field name="printInfoBack" type="text" />
              <ErrorMessage name="printInfoBack" component="div" />
            </div>

            <div>
              <label htmlFor="quantity">Quantity</label>
              <Field name="quantity" type="number" />
              <ErrorMessage name="quantity" component="div" />
            </div>

            <div>
              <label htmlFor="size">T-shirt Size</label>
              <Field as="select" name="size">
                <option value="">Select Size</option>
                <option value="S">Small</option>
                <option value="M">Medium</option>
                <option value="L">Large</option>
              </Field>
              <ErrorMessage name="size" component="div" />
            </div>

            <div>
              <label htmlFor="address">Address</label>
              <Field name="address" type="text" />
              <ErrorMessage name="address" component="div" />
            </div>

            <div>
              <label htmlFor="deliveryDate">Delivery Date</label>
              <Field name="deliveryDate" type="date" />
              <ErrorMessage name="deliveryDate" component="div" />
            </div>

            <div>
              <label htmlFor="price">Price</label>
              <Field name="price" type="number" />
              <ErrorMessage name="price" component="div" />
            </div>

            <button className="button" type="submit">Submit Order</button>
          </Form>
    </Formik>
        </DialogContent>
        {/* <DialogActions>
          <button onClick={handleClose}>Cancel</button>
          <button className="button"type="submit">order</button>
        </DialogActions> */}
    </Dialog>
  )
}

export default Order