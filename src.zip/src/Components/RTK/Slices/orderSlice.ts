import { createSlice, PayloadAction } from '@reduxjs/toolkit'

export interface orderState {
   orderList : any
}


const initialState : orderState = {
   orderList : [],
}


export const orderSlice = createSlice(
   {
        name:"orderslice",
        initialState,
        reducers:{
           setOrderList : (state, action: PayloadAction<any[]>)=>
           {
              state.orderList = [...action.payload]
           }
        }
   }  
)

//export default orderSlice.reducer
export const { setOrderList } = orderSlice.actions;
