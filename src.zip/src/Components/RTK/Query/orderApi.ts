
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { BillValues, Order, OrderFormValues } from '../Types/types';

export const orderApi = createApi(
   {
         reducerPath : 'orderapi',
         baseQuery : fetchBaseQuery({
            baseUrl: 'http://localhost:8000/'
         }),
         endpoints : (builder)=>({
            getOrders: builder.query<Order, void>({
               query: () => 'orders',
             }),
             createOrder: builder.mutation<OrderFormValues, Partial<OrderFormValues>>({
               query: (newOrder) => ({
                 url: 'orders',
                 method: 'POST',
                 body: newOrder,
               }),
             }),
             updateOrder :builder.mutation<Order, {id: number, uOrder : Partial<Order>}>({
               query: ({id, uOrder}) => ({
                 url: `orders/${id}`,
                 method: 'PUT',
                 body: uOrder,
               }),
             }),
             deleteOrder: builder.mutation<void, any>({
               query: (id) => ({
                 url: `orders/${id}`,
                 method: 'DELETE',
               }),
             }),
             addBill: builder.mutation<BillValues, Partial<BillValues>>({
              query: (newBill) => ({
                url: 'BillList',
                method: 'POST',
                body: newBill,
              }),
            }),
         })
   }
)

export const { useGetOrdersQuery, useCreateOrderMutation, useDeleteOrderMutation, useUpdateOrderMutation, useAddBillMutation} = orderApi;