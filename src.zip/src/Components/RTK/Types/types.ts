
export interface OrderFormValues {
   orderNumber: string;
   customerName: string;
   email: string;
   phone: string;
   tShirtColor: string;
   printInfoFront: string;
   printInfoBack: string;
   quantity: number;
   size: string;
   address: string;
   deliveryDate: string;
   price: number;
   id:number
 }
 
 // Type for API response (can be the same as OrderFormValues, or extended)
 export interface Order {
   id: number; // Server-generated ID for the order
   orderNumber: string;
   customerName: string;
   email: string;
   phone: string;
   tShirtColor: string;
   printInfoFront: string;
   printInfoBack: string;
   quantity: number;
   size: string;
   address: string;
   deliveryDate: string;
   price: number;
   // createdAt: string; // API might return a created date
 }

 export interface OrderValues {
  id: number; // Server-generated ID for the order
  orderNumber: string;
  customerName: string;
  email: string;
  phone: string;
  tShirtColor: string;
  printInfoFront: string;
  printInfoBack: string;
  quantity: number;
  size: string;
  address: string;
  deliveryDate: string;
  price: number;
  // createdAt: string; // API might return a created date
}

export interface BillValues{
  id: number; // Server-generated ID for the order
  orderNumber: string;
  customerName: string;
  phone: string;
  price: number;
  amountPaid : number;
  balanceAmount : number;
  deliveryDate : string
}