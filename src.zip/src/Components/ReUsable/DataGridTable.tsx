import React, { useMemo } from "react"
import { DataGrid, GridColDef } from '@mui/x-data-grid'

interface tableProps {
  columns?: any,
  rowData? : any ,
  onTableRowClick? : ()=>void,
}

const DataGridTable : React.FC<tableProps> = ({columns, rowData, onTableRowClick})=>
{
  
    console.log("props", columns, rowData);
  
    const rowOptions = useMemo(()=>
    {
        return rowData;
    }, [rowData])
  
    
   return <div style={{width:"99%", margin:"auto", border:"1px soild black"}}>
      <DataGrid
        columns={columns}
        rows={rowOptions}
        checkboxSelection={false}
        hideFooterPagination
        sx={{ border: 0 }}
        onRowClick={onTableRowClick}
      />
   </div>
}
export default DataGridTable