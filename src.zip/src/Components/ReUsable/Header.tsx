
import React from "react";

const Header: React.FC = () =>
{
   return <div className="header">
          Sports T-Shirt Management
   </div>
}


export default Header