import React, { useState } from "react";
import DataGridTable from "../ReUsable/DataGridTable";

import { useSelector } from 'react-redux'
import { RootState } from "../RTK/Store/store";
import { useDeleteOrderMutation, useGetOrdersQuery } from "../RTK/Query/orderApi";
import { GridColDef } from "@mui/x-data-grid";

import Order from "../Forms/Order";
import { Button, Stack } from "@mui/material";
import GenerateBill from "../Forms/GenerateBill";



// var arrTableHeader = GenericUtils.getCauseListHeaders();
// var arrRowData = this.getRowData();

// getRowData()
// {
//     var arrRowData = [];
//     var nRowCount = 0;
//     this.state.m_arrCauseList.map(oCause =>{
//         nRowCount++;
//         return arrRowData.push({
//             'nSlNo' : nRowCount, 
//             'm_strName' : oCause.m_strName, 
//             'm_nCauseId' : oCause.m_nCauseId,
//             'actionButtons' : this.actionButtons(oCause),
//             'oCauseArrData' : oCause})
//         });
//     return arrRowData;
// }

// var getCauseListHeaders = function()
// {
//     const arrTableHeader = [
//         {
//             name: 'SlNo',
//             selector: 'nSlNo',
//             sortable: true,
//             left: true,
//             minWidth: '23%',
//             maxWidth: '23%',
//         },
//         {
//             name: 'Cause List',
//             selector: 'm_strName',
//             sortable: true,
//             left: true,
//             minWidth: '55%',
//             maxWidth: '55%',
//         },
//         {
//             name: 'Actions',
//             selector: 'actionButtons',
//             right: true,
//             minWidth: '26%',
//             maxWidth: '26%',
//         },
//     ];
//     return arrTableHeader;
// }






const OrderList : React.FC = () =>
{
//   const getStoreData = useSelector((state:RootState)=>state.orderList);
//   console.log("getStoreData", getStoreData);

const { data: orders, error, isLoading, refetch } = useGetOrdersQuery();
const [deleteOrder, { isLoading: isDeleting, isSuccess, isError, error: deleteError }] = useDeleteOrderMutation();

const columns: GridColDef[] = [
  { field: 'id', headerName: 'ID', width: 70 },
  { field: 'orderNumber', headerName: 'orderNumber', width: 130 },
  { field: 'customerName', headerName: 'customerName', width: 150 },
 //  {
 //    field: 'email',
 //    headerName: 'email',
 //    width: 90,
 //  },
  {
   field: 'phone',
   headerName: 'phone',
   width: 120,
 },
 {
   field: 'price',
   headerName: 'price',
   width: 90,
 },
 {
   field: 'quantity',
   headerName: 'quantity',
   width: 90,
 },
 {
   field: 'size',
   headerName: 'size',
   width: 90,
 },
 // {
 //   field: 'printInfoFront',
 //   headerName: 'printInfoFront',
 //   width: 90,
 // },
 // {
 //   field: 'printInfoBack',
 //   headerName: 'printInfoBack',
 //   width: 90,
 // },
 {
   field: 'deliveryDate',
   headerName: 'deliveryDate',
   width: 120,
 },
 {
   field: 'action',
   headerName: 'Action',
   width: 300,
   sortable: false,
   renderCell: (params) => {
         // const onClick = (e: any) => {
         //   const currentRow = params.row;
         //   return alert(JSON.stringify(currentRow, null, 4));
         // };
         
         return (
           <Stack direction="row" spacing={1} className="p-3">
             <Button variant="outlined" color="warning" size="small" onClick={()=>onClickEdit(params.row)}>Edit</Button>
             <Button variant="outlined" color="error" size="small" onClick={()=>onClickDelete(params.row)}>Delete</Button>
             <Button variant="outlined" color="success" size="small" onClick={()=>onClickDelete(params.row)}>View Bill</Button>
           </Stack>
         );
     },
 }
];

const [open, setOpen] = useState<boolean>(false);
const [editData, setEditData] = useState<any>(null);
const [openBill, setOpenBill] = useState<boolean>(false);



const handleClickOpen = () => {
  setOpen(true);
};

const handleClose = () => {
  setOpen(false);
};

const handleClickOpenBill = () => {
  setOpenBill(true);
};

const handleCloseBill = () => {
  setOpenBill(false);
};

const generateBill = ()=>
{
  if(editData)
  {
    handleClickOpenBill();
  }
  else{
    alert("please select a record")
  }
}

const onClickDelete = async (paramsRowData: any) => {
  const currentRow = paramsRowData.id;
  // return alert(JSON.stringify(currentRow, null, 4));
  try {
   await deleteOrder(currentRow);
   refetch()
  } catch (error) {
    console.log(error);
  }

};

const onClickEdit = (paramsRowData: any) => {
  const currentRow = paramsRowData;
  setEditData(currentRow);
  handleClickOpen()
};

const handelRowClick = (rowData : any)=>
{
  console.log("rowData", rowData);
  

}


  
   if(isLoading)return <div><h1>Loading....</h1></div>
   console.log("orders", orders);
   return <div>
      <div>
         <h3 className="p-2">
         OrderList 
 
         <button className="flex-1 right float-right bg-blue-500 p-1 mr-8 " onClick={()=>handleClickOpen()}>New Order</button>
     
        <button className="flex-1 right float-right bg-blue-500 p-1 ml-8 mr-8" onClick={()=>generateBill()}>Generate Bill</button> 
          
         </h3>
         <hr/>
          <DataGridTable
               columns={columns} 
               rowData={orders || undefined}
               //onTableRowClick={handelRowClick}
          />
      </div>
      
       {
         open && <Order open={open} handleClose={handleClose} 
           refetchList ={refetch}
           existingOrder={editData}
           />
       }

       {
        openBill && <GenerateBill  open={openBill} handleClose={handleCloseBill}  existingOrderData={editData}/>
       }
      
   </div>
}
export default OrderList;